<?php declare(strict_types=1);

namespace PhpFuzzer\Instrumentation;

final class FileInfo {
    public array $blockIndexToPos = [];
}